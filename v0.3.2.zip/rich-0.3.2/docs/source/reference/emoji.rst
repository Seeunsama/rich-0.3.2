rich.box
========

.. automodule:: rich.emoji
    :members: Emoji

