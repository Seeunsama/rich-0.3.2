rich.render_width
=================

.. automodule:: rich.render_width
    :members:
