rich.highlighter
================

.. automodule:: rich.highlighter
    :members:
    :special-members: __call__

