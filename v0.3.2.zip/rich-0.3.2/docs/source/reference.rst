Reference
=========

.. toctree::
   :maxdepth: 3

   reference/color.rst
   reference/console.rst
   reference/emoji.rst
   reference/highlighter.rst
   reference/markdown.rst
   reference/render_width.rst
   reference/panel.rst
   reference/segment.rst
   reference/style.rst
   reference/syntax.rst
   reference/table.rst
   reference/text.rst
